exports.dummyHandler = function dummyHandler(payload, context) {
  return {"hello": "world"};
}

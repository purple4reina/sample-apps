# Switch to using a different bugzilla instance
BZ_API_URL = "https://bugzilla-dev.allizom.org"

# Applications useful for development, e.g. debug_toolbar, django_extensions.
# Always empty in production
LOCAL_APPS = []

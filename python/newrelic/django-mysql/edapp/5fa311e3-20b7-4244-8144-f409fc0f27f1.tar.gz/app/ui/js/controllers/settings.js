"use strict";
treeherderApp.controller('SettingsCtrl', [
    '$scope', '$log',
    function SheriffController($scope, $log){
    }
]);

'use strict';

var treeherder = angular.module('treeherder',
                                ['ngResource', 'ngSanitize', 'ngCookies',
                                 'LocalStorageModule']);

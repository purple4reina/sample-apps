"use strict";

userguideApp.controller('UserguideCtrl', [
    '$scope', '$log', function ($scope, $log) {
    }
]);
